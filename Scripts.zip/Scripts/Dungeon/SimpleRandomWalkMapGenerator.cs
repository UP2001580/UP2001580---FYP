using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

// Class for generating dungeon maps using a simple random walk algorithm
public class SimpleRandomWalkMapGenerator : AbstractDungeonGenerator
{

    [SerializeField]
    protected SimpleRandomWalkSO randomWalkParameters;
    
    // Method for running procedural generation using a simple random walk
    protected override void RunProceduralGeneration(){

        // Generate floor positions using random walk algorithm
        HashSet<Vector2Int> floorPosition = RunRandomWalk(randomWalkParameters, startPosition);

        // Clear existing tiles and visualize floor tiles
        tilemapVisualizer.Clear();
        tilemapVisualizer.PaintFloorTiles(floorPosition);

        // Generate walls based on floor positions
        WallGenerator.CreateWalls(floorPosition, tilemapVisualizer);
    }

    // Method for running the random walk algorithm
    protected HashSet<Vector2Int> RunRandomWalk(SimpleRandomWalkSO parameters, Vector2Int position)
    {
        var currentPosition = position;
        HashSet<Vector2Int> floorPositions = new HashSet<Vector2Int>();

        // Perform random walk iterations
        for (int i = 0; i < parameters.iterations; i++){

            // Generate a random walk path
            var path = ProceduralGenerationAlgorithm.SimpleRandomWalk(currentPosition, parameters.walkLength);
            
            // Add generated path to floor positions
            floorPositions.UnionWith(path);

            // Optionally start randomly each iteration
            if(parameters.startRandomlyEachIteration)
                currentPosition = floorPositions.ElementAt(Random.Range(0,floorPositions.Count));
        }
        return floorPositions; // Return generated floor positions
    }
}
