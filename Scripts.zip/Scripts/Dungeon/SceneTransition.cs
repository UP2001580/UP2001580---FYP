using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransition : RoomFirstDungeonGenerator
{
    [SerializeField] protected PathToLoad pathToLoad;
    [SerializeField] protected GameObject playerObject;

    public void Start(){
        Debug.Log(pathToLoad.pathName);
        tilemapVisualizer.Clear();
            foreach(GameObject spawner in GameObject.FindGameObjectsWithTag("Spawner"))
            {
                Destroy(spawner);
            }
            foreach(GameObject enemy in GameObject.FindGameObjectsWithTag("Enemy"))
            {
                Destroy(enemy);
            }

            CreateRooms();
            transform.position = (Vector3Int)stairsPosition.initialValue;
            playerObject.transform.position = (Vector3Int)playerInitial.initialValue;
    }
    public void OnTriggerEnter2D(Collider2D other) 
    {
        if(other.CompareTag("Player") && !other.isTrigger)
        {
            /*tilemapVisualizer.Clear();
            foreach(GameObject spawner in GameObject.FindGameObjectsWithTag("Spawner"))
            {
                Destroy(spawner);
            }
            foreach(GameObject enemy in GameObject.FindGameObjectsWithTag("Enemy"))
            {
                Destroy(enemy);
            }

            CreateRooms();
            transform.position = (Vector3Int)stairsPosition.initialValue;
            other.transform.position = (Vector3Int)playerInitial.initialValue;*/
            SceneManager.LoadScene(pathToLoad.pathName);
        }
        DontDestroyOnLoad(pathToLoad);
        Debug.Log(pathToLoad.pathName);
    }
}
