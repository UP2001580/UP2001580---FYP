using UnityEngine;

public class MouseUtil 
{
    public static Vector2 GetMousePosition2d()
    {
        return Camera.main.ScreenToWorldPoint(Input.mousePosition);
    }
}