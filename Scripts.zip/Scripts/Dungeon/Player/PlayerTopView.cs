using UnityEngine;

public class PlayerTopView : MonoBehaviour
{
    [SerializeField] private float speed = 5f;

    // Gun Variables
    [SerializeField] private GameObject BulletPrefab;
    [SerializeField] private Transform GunPoint;
    [Range(0.1f, 1f)]
    [SerializeField] private float fireRate = 0.5f;

    private Rigidbody2D rb;
    private Vector2 inputDirection;
    private float fireTimer; 

    private Vector2 mousePos;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        inputDirection.x = Input.GetAxisRaw("Horizontal");
        inputDirection.y = Input.GetAxisRaw("Vertical");
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        float angle = Mathf.Atan2(mousePos.y - transform.position.y, mousePos.x - transform.position.x) * Mathf.Rad2Deg - 90f;

        transform.localRotation = Quaternion.Euler(0, 0, angle);

        if (Input.GetMouseButton(0) && fireTimer <= 0f)
        {
            Shoot();
            fireTimer = fireRate;
        }
        else
        {
            fireTimer -= Time.deltaTime;
        }
    }

    private void FixedUpdate()
    {
        // Calculate desired velocity based on input direction and speed
        //Vector2 targetVelocity = inputDirection.normalized * speed;
        
        // Apply the velocity while preserving magnitude
        //rb.velocity = Vector2.MoveTowards(rb.velocity, targetVelocity, Time.fixedDeltaTime * speed);
        rb.velocity = new Vector2(inputDirection.x, inputDirection.y).normalized * speed;
    }

    private void Shoot()
    {
        Instantiate(BulletPrefab, GunPoint.position, transform.rotation);
    }
}
