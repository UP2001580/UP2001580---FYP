using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EnemyState
{
    idle, walk, attack
}

public class Enemys : MonoBehaviour
{
    public EnemyState curretState;
    public int health;
    public string enemyName;
    public int baseAttack;
    public float moveSpeed;
    public float shootingRange;
    public GameObject enemyBullet;
    public GameObject enemyBulletParent;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
}
