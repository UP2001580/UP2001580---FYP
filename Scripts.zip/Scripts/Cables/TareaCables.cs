using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TareaCables : MonoBehaviour
{
    public int conexionesActuales;
    [SerializeField] private PathToLoad pathToLoad;

    public void ComprobarVictoria()
    {
        if (conexionesActuales == 4)
        {
            //Destroy(this.gameObject, 1f);
            SceneManager.LoadScene(pathToLoad.pathName);
        }
    }
}