using UnityEngine;

public class Spawner : MonoBehaviour{

    public GameObject hexagonPrefab;
    private float nextTimeToSpawn = 0f;

    // Update is called once per frame
    void Update(){
        if (Time.time >= nextTimeToSpawn){
            Instantiate(hexagonPrefab, Vector3.zero, Quaternion.identity);
            nextTimeToSpawn = Time.time + 1.3f; // Spawn every x seconds
        }
    }
}

