using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour
{
    public float moveSpeed = 600f;
    float movement = 0f;
    private float timer = 0f;
    [SerializeField] private PathToLoad pathToLoad;

    // Update is called once per frame
    void Update(){
        movement = Input.GetAxisRaw("Horizontal");
        timer += Time.deltaTime;
        if (timer >= 10f) {
            SceneManager.LoadScene(pathToLoad.pathName);
        }
    }

    private void FixedUpdate() {
        transform.RotateAround(Vector3.zero, Vector3.forward, movement * Time.fixedDeltaTime * moveSpeed);
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        timer = 0f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
