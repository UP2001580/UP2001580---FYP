using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


//ESTA VAINA NO SIRVE PARA NADA; ESTA EN SCENE MANAGERS > LOADNEXTSCENE



public class LevelScript : MonoBehaviour
{
    // Progressive level Unlocking
    public void Pass(){
        int currentLevel = SceneManager.GetActiveScene().buildIndex;

        if(currentLevel >= PlayerPrefs.GetInt("Levels unlocked")){
            PlayerPrefs.SetInt("Levels unlocked", currentLevel + 1);
        }

        //Check if it works in Unity console
        Debug.Log("LEVEL " + PlayerPrefs.GetInt("Levels unlocked") + "UNLOCKED");
    }
}