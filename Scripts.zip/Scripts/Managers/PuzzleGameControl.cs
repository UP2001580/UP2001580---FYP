using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PuzzelGameControl : MonoBehaviour
{
    [SerializeField] private Transform[] pictures; // Reference Pictures
    [SerializeField] private GameObject winText; // Reference GameObject Text
    [SerializeField] private Button continueButton; // Reference Button
    public static bool youWin; // Flag to track if the player has won

    private bool allZero = true; // Flag to track if all rotation values are zero

    void Start()
    {
        winText.SetActive(false); // Hide winText
        continueButton.gameObject.SetActive(false); // Hide Button
        youWin = false; // Reset win flag

        // Check initial rotation values
        CheckRotationValues();
    }

    void Update()
    {
        // Check rotation values only when a picture's rotation changes and the game is not already won
        if (!youWin && !allZero)
        {
            CheckRotationValues();
        }
    }

    // Check rotation values of all pictures
    void CheckRotationValues()
    {
        allZero = true; // Assume all rotation values are zero initially
        foreach (Transform picture in pictures)
        {
            // If any rotation value is not zero, set allZero flag to false and break the loop
            if (picture.rotation.z != 0)
            {
                allZero = false;
                break;
            }
        }

        // If all rotation values are zero, player wins
        if (allZero)
        {
            youWin = true;
            winText.SetActive(true); // Show winText when winning condition is met
            continueButton.gameObject.SetActive(true); // Show Button when winning condition is met
        }
    }
}
