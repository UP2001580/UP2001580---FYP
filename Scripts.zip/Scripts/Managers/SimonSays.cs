using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SimonSays : MonoBehaviour
{
    public Image previewImage;
    public GameObject notPressedObject;
    public List<Color> colors;
    public int numOfColors;
    public int showColors; 
    public int remainingColors;
    public GameObject remainingColorsTextObject;
    public List<int> sequence;
    public GameObject endSceneObject;
    public int highscore;
    public Text highscoreText;

    void Start()
    {
        sequence = new List<int>();
        StartSimonSaysGame();
    }

    public void StartSimonSaysGame()
    {
        StartCoroutine(StartGameCoroutine());
    }

    public void GenerateSequence()
    {
        numOfColors++;
        sequence.Add(Random.Range(0, 4));
        ShowPreview();
    }

    public void ShowPreview()
    {
        if (sequence.Count <= showColors)
        {
            previewImage.color = Color.white;
            showColors = 0;
            notPressedObject.SetActive(false);
        }
        else
        {
            previewImage.color = colors[sequence[showColors]];
            StartCoroutine(ShowNext());
        }
    }

    public void HandleColorButton(int ID)
    {
        if (ID == sequence[showColors])
        {
            showColors++;
            remainingColors--;

            if (showColors == sequence.Count)
            {
                notPressedObject.SetActive(true);
                Text remainingColorsText = remainingColorsTextObject.GetComponent<Text>();
                if (remainingColorsText != null)
                {
                    remainingColorsText.text = "";
                }
                remainingColors = 0;
                showColors = 0;
                StartSimonSaysGame(); 
            }
        }
        else
        {
            endSceneObject.SetActive(true);
            notPressedObject.SetActive(true);
            highscore = PlayerPrefs.GetInt("HighScore");
            if (numOfColors > highscore)
            {
                highscore = numOfColors;
                PlayerPrefs.SetInt("HighScore", highscore); 
            }

            if (highscoreText != null)
            {
                highscoreText.text = "HighScore: " + highscore; 
            }

            Text remainingColorsText = remainingColorsTextObject.GetComponent<Text>();
            if (remainingColorsText != null)
            {
                remainingColorsText.text = "";
            }
            remainingColors = 0;
            showColors = 0;
        }
    }

    public void RestartGame()
    {
        sequence = new List<int>();
        numOfColors = 0;
        endSceneObject.SetActive(false);
        StartSimonSaysGame(); 
    }

    IEnumerator StartGameCoroutine()
    {
        yield return new WaitForSeconds(0.5f);
        GenerateSequence();
    }

    IEnumerator ShowNext()
    {
        yield return new WaitForSeconds(0.3f);
        previewImage.color = Color.white;
        yield return new WaitForSeconds(0.5f);
        showColors++;
        ShowPreview();
    }
}
