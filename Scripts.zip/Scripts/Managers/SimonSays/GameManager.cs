using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour{
    [SerializeField] private GameObject winText; // Reference GameObject Text
    [SerializeField] private Button continueButton; // Reference Button

    public SpriteRenderer[] colours;
    public AudioSource[] buttonSounds;

    private int colourSelect;

    public float stayLit;

    private float stayLitCounter;

    public float waitBetweenLights;
    private float waitBetweenCounter;

    private bool shouldBeLit;
    private bool shouldBeDark;

    public List<int> activeSequence;
    private int positionInSequence;

    private bool gameActive;
    private int inputInSequence;

    public AudioSource correct;
    public AudioSource incorrect;

    [SerializeField] public int desiredSequenceLength = 11; // Customize the desired sequence length here
    [SerializeField] private PathToLoad pathToLoad;
    [SerializeField] public string sceneToLoad = "Sliding Puzzle"; // Name of the scene to load

    // Start is called before the first frame update
    void Start(){
        winText.SetActive(false);
        continueButton.gameObject.SetActive(false);
        StartGame();
    }

    // Update is called once per frame
    void Update(){
        if(shouldBeLit){
            stayLitCounter -= Time.deltaTime;
            
            if(stayLitCounter < 0){
                colours[activeSequence[positionInSequence]].color = new Color(colours[activeSequence[positionInSequence]].color.r, colours[activeSequence[positionInSequence]].color.g, colours[activeSequence[positionInSequence]].color.b, 0.25f);
                buttonSounds[activeSequence[positionInSequence]].Stop();
                
                shouldBeLit = false;
                shouldBeDark = true;
                waitBetweenCounter = waitBetweenLights;
                positionInSequence++;
            }
        }

        if(shouldBeDark){
            waitBetweenCounter -=Time.deltaTime;

            if(positionInSequence >= activeSequence.Count){
                shouldBeDark = false;
                gameActive = true;
            } else {
                if (waitBetweenCounter < 0){
                    colours[activeSequence[positionInSequence]].color = new Color(colours[activeSequence[positionInSequence]].color.r, colours[activeSequence[positionInSequence]].color.g, colours[activeSequence[positionInSequence]].color.b, 1f);
                    buttonSounds[activeSequence[positionInSequence]].Play();

                    stayLitCounter = stayLit;
                    shouldBeLit = true;
                    shouldBeDark = false;
                }
            }
        }

        // Check if the game has been won (activeSequence.Count reaches desiredSequenceLength)
        if (activeSequence.Count == desiredSequenceLength && !gameActive){
            WinGame();
        }
    }

    public void StartGame(){
        activeSequence.Clear();

        positionInSequence = 0;
        inputInSequence = 0;

        colourSelect = Random.Range(0,colours.Length);

        activeSequence.Add(colourSelect);

        colours[activeSequence[positionInSequence]].color = new Color(colours[activeSequence[positionInSequence]].color.r, colours[activeSequence[positionInSequence]].color.g, colours[activeSequence[positionInSequence]].color.b, 1f);
        buttonSounds[activeSequence[positionInSequence]].Play();

        stayLitCounter = stayLit;
        shouldBeLit = true;
    }


    public void ColorPressed(int whichButton){
        if(gameActive){
            if(activeSequence[inputInSequence] == whichButton){
                Debug.Log("Correct");

                inputInSequence++;
                if(inputInSequence >= activeSequence.Count){
                    positionInSequence = 0;
                    inputInSequence = 0;

                    colourSelect = Random.Range(0,colours.Length);

                    activeSequence.Add(colourSelect);

                    colours[activeSequence[positionInSequence]].color = new Color(colours[activeSequence[positionInSequence]].color.r, colours[activeSequence[positionInSequence]].color.g, colours[activeSequence[positionInSequence]].color.b, 1f);
                    buttonSounds[activeSequence[positionInSequence]].Play();

                    stayLitCounter = stayLit;
                    shouldBeLit = true;

                    gameActive = false;

                    correct.Play();
                }
            } else {
                Debug.Log("Wrong");
                incorrect.Play();
                gameActive = false;
                // Restart the game sequence with a delay of 2 seconds
                Invoke("RestartGameSequence", 2f);
            }
        }
    }

    void RestartGameSequence(){
        StartGame(); // Restart the game sequence
    }

    void WinGame(){
        winText.SetActive(true); // Activate win text
        continueButton.gameObject.SetActive(true); // Enable continue button
        gameActive = false;
    }

    public void LoadNextScene(){
        SceneManager.LoadScene(pathToLoad.pathName); // Load the next scene
    }
}
