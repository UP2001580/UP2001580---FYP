using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScenesManager : MonoBehaviour
{
    public static ScenesManager Instance;
    
    private void Awake() 
    {
        // Instance = to this class
        Instance = this;
    }

    // When adding new scenes to game do 2 things:
    // 1. Add them on enum.
    // 2. Same order than in Unity (Build Settings: file > build settings)

    // enum = List of constants
    public enum Scene {
        MainMenu, Level_1, Level_2
    }

    public void LoadScene(Scene scene){
        SceneManager.LoadScene(scene.ToString());
    }

    public void LoadNewGame(){
        SceneManager.LoadScene(6);
    }

    public void LoadNextScene(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        
        int currentLevel = SceneManager.GetActiveScene().buildIndex;

        if(currentLevel >= PlayerPrefs.GetInt("Levels unlocked")){
            PlayerPrefs.SetInt("Levels unlocked", currentLevel + 1);
        }

        //Check if it works in Unity console
        //Debug.Log("LEVEL " + PlayerPrefs.GetInt("Levels unlocked") + "UNLOCKED");
    }

    public void LoadMainMenu(){
        SceneManager.LoadScene(Scene.MainMenu.ToString());
    }

    //public void OpenLevel(int levelID)
    //{
    //    SceneManager.LoadScene(levelID);
    //}
}
