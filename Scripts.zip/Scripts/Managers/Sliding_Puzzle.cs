using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Sliding_Puzzle : MonoBehaviour
{
    [SerializeField] private Transform gameTransform;
    [SerializeField] private Transform piecePrefab;
    [SerializeField] private GameObject winText; // Reference GameObject Text
    [SerializeField] private Button continueButton; // Reference Button
    [SerializeField] private PathToLoad pathToLoad;

    private List<Transform> pieces;
    private int emptyLocation;
    private int size;
    private bool shuffling = false;

    // Create game set up (Size x Size pieces)
    private void CreateGamePieces(float gapThickness){
        pieces = new List<Transform>(); 

        float width = 1f / size;
        for (int row = 0; row < size; row++){
            for (int column = 0; column < size; column++){
                Transform piece = Instantiate(piecePrefab, gameTransform);
                pieces.Add(piece);

                // Pieces will be in a game board going from -1 to 1.
                piece.localPosition = new Vector3(-1f + (2f * width * column) + width,
                                                  1f - (2f * width * row) - width, 0);
                piece.localScale = ((2f * width) - gapThickness) * Vector3.one;
                piece.name = $"{(row * size) + column}";

                // We want an empty space in the bottom right.
                if (row == size - 1 && column == size - 1){
                    emptyLocation = (size * size) - 1;
                    piece.gameObject.SetActive(false);
                }
                else {
                    // UV and mesh setup
                    float gap = gapThickness / 2;
                    Mesh mesh = piece.GetComponent<MeshFilter>().mesh;
                    Vector2[] uv = new Vector2[4];

                    // UV coord order: (0, 1), (1, 1), (0, 0), (1, 0)
                    uv[0] = new Vector2((width * column) + gap, 1f - ((width * (row + 1)) - gap));
                    uv[1] = new Vector2((width * (column + 1)) - gap, 1f - ((width * (row + 1)) - gap));
                    uv[2] = new Vector2((width * column) + gap, 1f - ((width * row) + gap));
                    uv[3] = new Vector2((width * (column + 1)) - gap, 1f - ((width * row) + gap));

                    // Assign new UVs to mesh
                    mesh.uv = uv;
                }
            }
        }
    }

    // Start is called before first frame update.
    void Start(){
        size = 3;
        CreateGamePieces(0.0f);
        Shuffle(); // Perform brute force shuffle at the beginning
        winText.SetActive(false);
        continueButton.gameObject.SetActive(false);
    }

    void Update(){

        // Check for completion
        if (!shuffling && CheckCompletion()){
            shuffling = true;
            StartCoroutine(WaitShuffle(3f));
        }

        // On click send out ray to see if piece was clicked.
        if (Input.GetMouseButtonDown(0)){
            RaycastHit2D hit = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero);
            if (hit) {
                // Go through list, the index tells position.
                for (int i = 0; i < pieces.Count; i++){
                    if (pieces[i] == hit.transform)
                    {
                        // Check each direction to see if valid move.
                        // Break success so we dont carry on swap back again.
                        if (SwapIfValid(i, -size, size)) { break; }
                        if (SwapIfValid(i, size, size)) { break; }
                        if (SwapIfValid(i, -1, 0)) { break; }
                        if (SwapIfValid(i, 1, size - 1)) { break; }
                    }
                }
            }
        }
    }

    // Column Check to stop horizontal moves wrapping
    private bool SwapIfValid(int i, int offset, int columnCheck){
        if (((i % size) != columnCheck) && ((i + offset) == emptyLocation)){
            // Swap them in game state.
            Transform temp = pieces[i];
            pieces[i] = pieces[i + offset];
            pieces[i + offset] = temp;

            // Swap their transforms.
            Vector3 tempPos = pieces[i].localPosition;
            pieces[i].localPosition = pieces[i + offset].localPosition;
            pieces[i + offset].localPosition = tempPos;

            // Update empty location.
            emptyLocation = i;
            return true;
        }
        return false;
    }


    // We name the places in order so we can use this to check completion.
    private bool CheckCompletion(){
        for (int i = 0; i < pieces.Count; i++){
            if (pieces[i].name != $"{i}"){
                return false;
            }
        }
        winText.SetActive(true);
        continueButton.gameObject.SetActive(true);
        return true;
    }

    private IEnumerator WaitShuffle(float duration){
        yield return new WaitForSeconds(duration);
        //Shuffle();
        shuffling = false;
    }

    // Brute force shuffling.
    private void Shuffle(){
        int count = 0;
        int last = 0;
        while (count < (size * size * size)) {
            
            // Pick random location
            int rnd = Random.Range(0, size * size);

            // Only thing we forbid is undoing last move.
            if (rnd == last) { continue;}
            last = emptyLocation;

            // Try surrounding spaces looking for valid move.
            if(SwapIfValid(rnd, -size, size)) {
                count++;
            } else if (SwapIfValid(rnd, +size, size)) {
                count++;
            } else if (SwapIfValid(rnd, -1, 0)) {
                count++;
            } else if (SwapIfValid(rnd, +1, size - 1)) {
                count++;
            }
        }
    }

    // Display winning text and enable continue button
    private void DisplayWinTextAndButton()
    {
        winText.SetActive(true);
        continueButton.gameObject.SetActive(true);
    }

    public void changeScene() {
        SceneManager.LoadScene(pathToLoad.pathName);
    }
}
