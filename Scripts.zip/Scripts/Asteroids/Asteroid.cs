using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour{
    [SerializeField] private ParticleSystem destroyedParticles;
    public int size = 3;

    public GameManagerAsteroids gameManager;

    private void Start(){
        //Scale in isze
        transform.localScale = 0.5f * size * Vector3.one;

        //Add movement to asteriois, bigger = slower.
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        Vector2 direction = new Vector2(Random.value, Random.value).normalized;
        float spawnSpeed = Random.Range(4f - size, 5f - size);
        rb.AddForce(direction * spawnSpeed, ForceMode2D.Impulse);

        //Register Creation
        gameManager.asteroidsCount++;
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        //Asteroids are only destroyed with bullets.
        if(collision.CompareTag("Bullet")){
            //Register destruction with game manager
            gameManager.asteroidsCount--;

            //Destroy bullet after contact wiht asteroid
            Destroy(collision.gameObject);

            //If sixe > 1 spawn 2 smaller asteroids of size - 1.
            if (size > 1){
                for(int i = 0; i < 2; i++){
                    Asteroid newAsteroid = Instantiate(this, transform.position, Quaternion.identity);
                    newAsteroid.size = size - 1;
                    newAsteroid.gameManager = gameManager;
                }
            }

            //Spawn particles of destruction
            Instantiate(destroyedParticles, transform.position, Quaternion.identity);

            //Destroy this asteroi
            Destroy(gameObject);
        }
    }
}
