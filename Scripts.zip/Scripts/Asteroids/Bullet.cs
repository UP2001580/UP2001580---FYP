using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] private float bulletlifeTime = 1f;

    // Destry after a set period of time.
    private void Awake() {
        Destroy(gameObject, bulletlifeTime);
    }
}
