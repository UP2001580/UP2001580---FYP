using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

public class ShipMovement : MonoBehaviour
{
    public FixedJoystick Joystick;

    [Header("Object references")]
    [SerializeField] private Transform bulletSpawn;
    [SerializeField] private Rigidbody2D bulletPrefab;
    [SerializeField] private ParticleSystem destroyedParticles;

    private bool isAlive = true;
    Rigidbody2D rb;
    Vector2 move;
    public float moveSpeed;
    public static bool PointerDown = false;
    [SerializeField] private float bulletSpeed = 8f;
    private void Start(){
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update(){
        if (isAlive){
        move.x = Joystick.Horizontal;
        move.y = Joystick.Vertical;

        //rotation
        float hAxis = move.x;
        float vAxis = move.y;
        float zAxis = Mathf.Atan2 (hAxis, vAxis) * Mathf.Rad2Deg;
        transform.eulerAngles = new Vector3 (0f, 0f, -zAxis);
        HandleSooting();
        }
    }

    private void HandleSooting(){
        // Shooting
        if (Input.GetKeyDown(KeyCode.Space)){
            Rigidbody2D bullet = Instantiate(bulletPrefab, bulletSpawn.position, Quaternion.identity);

            //Inherit ship Velocity for bullet
            Vector2 shipVelocity = rb.velocity;
            Vector2 shipDirection = transform.up;
            float shipForwardSpeed = Vector2.Dot(shipVelocity, shipDirection);

            //Dont want to inherit in opposite direction (Stationary Bullets)
            if(shipForwardSpeed < 0){
                shipForwardSpeed = 0;
            }
             bullet.velocity = shipDirection * shipForwardSpeed;

            // Add force to propel bullet in players direction
            bullet.AddForce(bulletSpeed * transform.up, ForceMode2D.Impulse);
        }
    }

    private void FixedUpdate(){
        if(PointerDown){
            rb.position = Vector3.zero;
        } else {
            rb.MovePosition (rb.position + move * moveSpeed * Time.fixedDeltaTime);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision){
        if(collision.CompareTag("Asteroid")){
            isAlive = false;

            //Get reference to the GameManager
            GameManagerAsteroids gameManager = FindAnyObjectByType<GameManagerAsteroids>();

            //Restart game after delay
            gameManager.GameOver();

            //Spawn particles of destruction on ship
            Instantiate(destroyedParticles, transform.position, Quaternion.identity);

            //Destroy player
            Destroy(gameObject);
        }
    }
}
