using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Text template object")]

public class TextTemplate : ScriptableObject
{
    [TextArea(7,15)]
    public string mainText;
    [Space(50)]
    [Header("Options Section")]
    [Space(10)]
    public int optionAmount;
    public List<string> responses = new List<string>();
    public int [] arrayReferences = new int[3];
    public bool quitButtons;
    public bool changeAnotherOptions;
    [Space(50)]
    [Header("Dialogs Section")]
    [Space(10)]
    public List<string> dialogs = new List<string>();
    public int optionsIndex;
    public bool endGame;
    [Space(50)]
    [Header("Scene Change")]
    [Space(10)]
    public bool changeScene;
    public string sceneToLoad;
    public string pathName;
}
