using UnityEngine;

[CreateAssetMenu] 
public class PathToLoad : ScriptableObject
{
    public string pathName;
    
}
