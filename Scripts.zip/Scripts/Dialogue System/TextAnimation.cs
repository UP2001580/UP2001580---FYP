using System.Collections;
using TMPro;
using UnityEngine;

public class TextAnimation : MonoBehaviour
{
    private string historyTextContent;
    private bool doingAnimation;
    private IEnumerator animationCoroutine;
    [SerializeField] TextMeshProUGUI historyText;

    public bool IsDoingAnimation() => doingAnimation;

    public void SetDoingAnimation(bool newAnimationState)
    {
        doingAnimation = newAnimationState;
    }

    public void StopAnimations()
    {
        StopCoroutine(animationCoroutine);
        StopCoroutine(FinishDialog());
    }

    public void AnimateText()
    {
        animationCoroutine = AnimateHistoryText();
        if(!doingAnimation)
        {
            StartCoroutine(animationCoroutine);
        }
    }

    private IEnumerator FinishDialog()
    {
        yield return new WaitUntil(() => (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyUp(KeyCode.Space)));
        StopCoroutine(animationCoroutine);
        historyText.text = historyTextContent;
        yield return new WaitForSeconds(0.03f);
        yield return new WaitUntil(() => (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyUp(KeyCode.Space)));
        doingAnimation = false;
    }
    private IEnumerator AnimateHistoryText()
    {
        doingAnimation = true;
        historyTextContent = historyText.text;
        historyText.text = string.Empty;

        char[] hisrotyLetters = historyTextContent.ToCharArray();
        IEnumerator finish = FinishDialog();
        StartCoroutine(finish);

        for(int i = 0; i < hisrotyLetters.Length; i++)
        {
            historyText.text += hisrotyLetters[i];
            yield return new WaitForSeconds(0.03f);
        }

        StopCoroutine(finish);

        yield return new WaitUntil(() => (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyUp(KeyCode.Space)));
        doingAnimation = false;

    }
    
}