using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.IO;

public class TextController : MonoBehaviour
{
    private TextAnimation textAnimation;
    private List<Button> currentOptions = new List<Button>();
    [SerializeField] private TextTemplate template;
    [SerializeField] private TextTemplate[] arrayTemplates;
    [SerializeField] private TextMeshProUGUI mainText;
    [SerializeField] private GameObject responseButtonPrefab;
    [SerializeField] private Transform responseContent;
    [SerializeField] private PathToLoad pathToLoad;

    private void Awake() 
    {
        textAnimation = GetComponent<TextAnimation>();
    }

    private void Start()
    {
        template = arrayTemplates[0];
        ShowText();
    }

    private void ShowText()
    {
        mainText.text = template.mainText;
        CreateResponses(template.optionAmount);
        textAnimation.AnimateText();
    }

    private void CreateResponses(int amount)
    {
        List<int> indexes = new List<int>();
        for(int i = 0; i < amount; i++)
        {
            Button response = Instantiate(responseButtonPrefab, responseContent).GetComponent<Button>();
            currentOptions.Add(response);
            response.GetComponentInChildren<TextMeshProUGUI>().text = template.responses[i];

            indexes.Add(i);
            int currentIndex = indexes[i];

            response.onClick.AddListener(
                () => {ControlButtons(currentIndex);
                }
            );
        }
    }

    private void ControlButtons(int index)
    {
        template = arrayTemplates[template.arrayReferences[index]];

        if(template.quitButtons){
            DisableButton();
        }
        textAnimation.StopAnimations();
        textAnimation.SetDoingAnimation(false);
        ShowText();

        pathToLoad.pathName = template.pathName;

        if(template.changeScene){
            DontDestroyOnLoad(pathToLoad);
            LoadNextScene(template.sceneToLoad);
            Debug.Log(pathToLoad.pathName);

        }
    }
    private void DisableButton()
    {
        /*foreach(var item in currentOptions)
        {
            Destroy(item);
        }*/

        for(int i = 0; i < currentOptions.Count; i++)
        {
            Destroy(currentOptions[i].gameObject);
        }
        currentOptions.Clear();
    }

    private void LoadNextScene(string sceneToLoad)
    {
        SceneManager.LoadScene(sceneToLoad); // Load the specified scene
    }
}
