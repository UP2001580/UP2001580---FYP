using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIMainManu : MonoBehaviour
{
    [SerializeField] Button _newGame;

    void Start()
    {
        _newGame.onClick.AddListener(StartNewGame);

        // Scale UI elements based on screen aspect ratio
        ScaleUIElements();
    }

    private void StartNewGame()
    {
        // Implement your new game logic here
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    private void ScaleUIElements()
    {
        // Get the CanvasScaler component of the Canvas
        CanvasScaler canvasScaler = GetComponent<CanvasScaler>();

        // Calculate the reference resolution ratio
        float refRatio = canvasScaler.referenceResolution.x / canvasScaler.referenceResolution.y;

        // Get the aspect ratio of the screen
        float screenRatio = (float)Screen.width / Screen.height;

        // Calculate the scale factor for the button based on the aspect ratio
        float scaleFactor = refRatio / screenRatio;

        // Scale the UI elements based on the calculated scale factor
        transform.localScale = new Vector3(scaleFactor, scaleFactor, 1f);
    }
}
