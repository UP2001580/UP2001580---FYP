using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerJoystick : MonoBehaviour {

    public FixedJoystick joystick;
    public float moveSpeed;

    float horizontalInput, verticalInput;
    void Start() {
        
    }

    // Update is called once per frame
    void Update() {
        
    }

    private void FixedUpdate() {
        horizontalInput = joystick.Horizontal * moveSpeed;
        verticalInput = joystick.Vertical * moveSpeed;

        transform.Translate(horizontalInput, verticalInput, 0);

    }
}
