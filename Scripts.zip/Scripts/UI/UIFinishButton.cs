using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIFinishButton : MonoBehaviour
{
    public Button button;

    private void Start()
    {
        // Assuming you have assigned the button component in the Unity Editor
        button.onClick.AddListener(UnlockNextLevel);
    }

    void UnlockNextLevel()
    {
        int unlockedLevel = PlayerPrefs.GetInt("UnlockedLevel", 1);
        int maxLevel = SceneManager.sceneCountInBuildSettings - 1; // Subtract 1 because scene indices start from 0

        if (unlockedLevel < maxLevel)
        {
            unlockedLevel++;
            PlayerPrefs.SetInt("UnlockedLevel", unlockedLevel);
            PlayerPrefs.Save();
        }
    }
}
