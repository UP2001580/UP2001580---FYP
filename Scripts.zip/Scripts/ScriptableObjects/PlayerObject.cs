using UnityEngine;

[CreateAssetMenu]
public class PlayerObject : ScriptableObject
{
    public GameObject playerObject;
}
